#to run your flask server. Keep your port number for flask as 5025 .
# The run.sh file provided by you in home folder should start your flask server on localhost(127.0.0.1) on port (5025)
# ( Note that front end etc. need not be flask).

python app.py