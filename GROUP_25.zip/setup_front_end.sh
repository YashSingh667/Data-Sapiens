# install frontend dependencies
pip install Flask psycopg2